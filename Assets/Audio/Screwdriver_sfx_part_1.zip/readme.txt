randomize walking steps sounds

There's "player getting hit" and "player dashing" sfx missing atm 
